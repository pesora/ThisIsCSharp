﻿namespace DiscardPattern
{
    internal class MainApp
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}