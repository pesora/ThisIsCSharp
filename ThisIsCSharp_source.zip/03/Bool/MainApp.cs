using System; 
 
namespace Bool 
{ 
    class MainApp 
    { 
        static void Main(string[] args) 
        { 
            bool a = true; 
            bool b = false; 
 
            Console.WriteLine(a); 
            Console.WriteLine(b); 
        } 
    } 
} 
