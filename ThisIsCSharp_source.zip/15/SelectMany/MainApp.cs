﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SelectMany
{
    class MainApp
    {
        static void Main(string[] args)
        {
        }
    }
}
